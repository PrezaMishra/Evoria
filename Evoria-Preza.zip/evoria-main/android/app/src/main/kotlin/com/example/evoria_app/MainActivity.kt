package com.example.evoria_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
